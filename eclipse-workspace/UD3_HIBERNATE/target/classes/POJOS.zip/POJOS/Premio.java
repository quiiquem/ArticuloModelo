package POJOS;

public class Premio {

}
